﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TrackBar;

namespace Add_Calendar_Appointment
{
    public partial class Add_Appointment_Form : Form
    {
        private string Date { get; set; }
        public delegate void MyDel(string dt);
        public MyDel d { get; set; }
        public Add_Appointment_Form(string Date)
        {
            this.Date = Date;
            InitializeComponent();
            groupBox1.Enabled = false;
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private int NewID()
        {
            string query = "SELECT ID FROM Appointment";
            List<int> li = new List<int>();
            foreach (DataRow i in DBHelper.Instance.GetRecords(query).Rows)
            {
                li.Add(Convert.ToInt32(i["ID"].ToString()));
            }
            int id = li[li.Count - 1] + 1;
            return id;
        }
        public void AddReminder(int id)
        {
            SqlParameter[] p = new SqlParameter[3];
            p[0] = new SqlParameter("@ID_Reminder", id);
            p[1] = new SqlParameter("@TimeReminder", Convert.ToDateTime(dateTimePicker3.Value.ToString()));
            p[2] = new SqlParameter("@Reminder", txtReminder.Text);
            string query = "INSERT INTO Reminder (ID_Appointment, TimeReminder, Reminder) " +
                    "VALUES (@ID_Reminder, @TimeReminder, @Reminder)";
            DBHelper.Instance.ExecuteDB(query, p);
            MessageBox.Show("Add reminder successfully!");
        }
        public void AddAppointment(int id, bool kt)
        {
            SqlParameter[] p = new SqlParameter[7];
            p[0] = new SqlParameter("@ID", id);
            p[1] = new SqlParameter("@NAME", txtName.Text.ToString());
            p[2] = new SqlParameter("@LOCATION", txtLocation.Text.ToString());
            p[3] = new SqlParameter("@DATE", Convert.ToDateTime(Date));
            p[4] = new SqlParameter("@BEGINTIME", Convert.ToDateTime(dateTimePicker1.Value.TimeOfDay.ToString()));
            p[5] = new SqlParameter("@ENDTIME", Convert.ToDateTime(dateTimePicker2.Value.TimeOfDay.ToString()));
            p[6] = new SqlParameter("@GROUPMEETING", kt);

            string query = "INSERT INTO Appointment (ID, Name, Location, Date, Begin_Time, End_Time, GroupMeeting) " +
                "VALUES (@ID, @NAME, @LOCATION, @DATE, @BEGINTIME, @ENDTIME, @GROUPMEETING)";
            DBHelper.Instance.ExecuteDB(query, p);
            MessageBox.Show("Add appointment successfully!");
        }
        public void ReplaceAppointment(int ID)
        {
            SqlParameter[] p = new SqlParameter[3];
            p[0] = new SqlParameter("@ID", ID);
            p[1] = new SqlParameter("@NAME", txtName.Text.ToString());
            p[2] = new SqlParameter("@LOCATION", txtLocation.Text.ToString());
            string query = "UPDATE Appointment SET Name = @NAME, Location = @LOCATION WHERE ID = @ID";
            DBHelper.Instance.ExecuteDB(query, p);
            MessageBox.Show("Replace successfully!");
        }

        public void AddParticipant(int ID) 
        {
            SqlParameter[] p = new SqlParameter[3];
            p[0] = new SqlParameter("@ID_GUEST", 1);
            p[1] = new SqlParameter("@ID_APPOINTMENT", ID);
            p[2] = new SqlParameter("@GUEST", "Hạ");
            string query = "INSERT INTO Participant (ID_Guest, ID_Appointment, Guest) " +
                "VALUES (@ID_GUEST, @ID_APPOINTMENT, @GUEST)";
            DBHelper.Instance.ExecuteDB(query, p);
            MessageBox.Show("Add participant successfully!");
        }

        public void CheckGroupTrue()
        {
            bool kt = true;
            string query = "";
            string begin = dateTimePicker1.Value.TimeOfDay.ToString();
            string end = dateTimePicker2.Value.TimeOfDay.ToString();
            
            query = "SELECT * FROM Appointment WHERE Date = '" + this.Date + "' AND GroupMeeting = 'true'";
            DataTable dt = new DataTable();
            dt = DBHelper.Instance.GetRecords(query);
            foreach (DataRow i in dt.Rows)
            { 
                if (begin == i.ItemArray[4].ToString() && end == i.ItemArray[5].ToString())
                {
                    DialogResult d = MessageBox.Show("Already has group meeting at this time!\nDo you want to replace this?", "Coincident Group Meeting", MessageBoxButtons.YesNo);
                    if (d == DialogResult.Yes)
                    {
                        ReplaceAppointment(Convert.ToInt32(i["ID"].ToString()));
                        kt = false;
                    }
                    else
                    {
                        MessageBox.Show("Please choose an available time!");
                        kt = false;
                    }
                }
            }
            if (kt)
            {
                int id = NewID();
                AddAppointment(id, false);
                if (checkReminder.Checked)
                {
                    AddReminder(id);
                }
            }
        }

        public void CheckGroupFalse()
        {
            string query = "";
            bool kt = true;
            string begin = dateTimePicker1.Value.TimeOfDay.ToString();
            string end = dateTimePicker2.Value.TimeOfDay.ToString();

            query = "SELECT * FROM Appointment WHERE Date = '" + this.Date + "' AND GroupMeeting = 'false'";
            foreach (DataRow i in DBHelper.Instance.GetRecords(query).Rows)
            {
                if (begin == i.ItemArray[4].ToString() && end == i.ItemArray[5].ToString())
                {
                    DialogResult d = MessageBox.Show("Already has appointment at this time!\nDo you want to replace this?", "Coincident time", MessageBoxButtons.YesNo);
                    if (d == DialogResult.Yes)
                    {
                        ReplaceAppointment(Convert.ToInt32(i["ID"].ToString()));
                        kt = false;
                    }
                    else
                    {
                        MessageBox.Show("Please choose an available time!");
                        kt = false;
                    }
                }
            }

            query = "SELECT * FROM Appointment WHERE Date = '" + this.Date + "' AND GroupMeeting = 'true'";
            DataTable dt = new DataTable();
            dt = DBHelper.Instance.GetRecords(query);
            foreach (DataRow i in dt.Rows)
            {
                if (txtName.Text.ToString() == i["Name"].ToString() && begin == i.ItemArray[4].ToString() && end == i.ItemArray[5].ToString())
                {
                    DialogResult d = MessageBox.Show("Exist Group Meeting!\nDo you want to join this?", "Join Group Meeting", MessageBoxButtons.YesNo);
                    if (d == DialogResult.Yes)
                    {
                        AddParticipant(Convert.ToInt32(i["ID"].ToString()));
                        kt = false;
                    }
                }
            }

            if(kt)
            {
                int id = NewID();
                AddAppointment(id, false);
                if (checkReminder.Checked)
                {
                    AddReminder(id);
                }
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            bool check = true;

            if (txtName.Text == "")
            {
                MessageBox.Show("Empty Name!!!");
                check = false;
            }
            int r = DateTime.Compare(dateTimePicker2.Value, dateTimePicker1.Value);
            if (r != 1)
            {
                MessageBox.Show("Negative duration!!!");
                check = false;
            }

            if (check)
            {
                if(checkGroup.Checked)
                {
                    CheckGroupTrue();
                }
                else
                {
                    CheckGroupFalse();
                }
            }
            d(null);
        }

        private void Add_Appointment_Form_Load(object sender, EventArgs e)
        {
            txtDate.Text = Date;
            dateTimePicker1.Value = Convert.ToDateTime(Date);
            dateTimePicker1.ShowUpDown = true;
            dateTimePicker1.CustomFormat = "hh:mm:ss";
            dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;

            dateTimePicker2.Value = Convert.ToDateTime(Date);
            dateTimePicker2.ShowUpDown = true;
            dateTimePicker2.CustomFormat = "hh:mm:ss";
            dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;

            dateTimePicker3.Value = Convert.ToDateTime(Date);
            dateTimePicker3.ShowUpDown = true;
            dateTimePicker3.CustomFormat = "dd/MM/yyyy hh:mm:ss";
            dateTimePicker3.Format = System.Windows.Forms.DateTimePickerFormat.Custom;

        }


        private void checkReminder_CheckedChanged(object sender, EventArgs e)
        {
            if(checkReminder.Checked == true) 
            {
                groupBox1.Enabled = true;
            }
            else 
            { 
                groupBox1.Enabled = false; 
            }
        }
    }
}
