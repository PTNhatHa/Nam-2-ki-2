﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Add_Calendar_Appointment
{
    public partial class Mainform : Form
    {
        public Mainform()
        {
            InitializeComponent();
            ShowDGV1(null);
            ShowDGV2(null);
        }

        public void ShowDGV1(string dt)
        {
            String query;
            if (dt == null)
            {
                query = "SELECT * FROM Appointment";
            }
            else
            {
                query = "SELECT * FROM Appointment WHERE Date = '" + dt + "'";
            }
            dataGridView1.DataSource = DBHelper.Instance.GetRecords(query);
        }
        public void ShowDGV2(string dt) 
        {
            String query;
            if (dt == null)
            {
                query = "SELECT ID, Name, Location, Date, Begin_Time, End_Time, GroupMeeting, TimeReminder, Reminder " +
                    "FROM Appointment, Reminder WHERE ID = ID_Appointment";
            }
            else
            {
                query = "SELECT ID, Name, Location, Date, Begin_Time, End_Time, GroupMeeting, TimeReminder, Reminder " +
                    "FROM Appointment, Reminder WHERE ID = ID_Appointment AND Date = '" + dt + "'";
            }
            dataGridView2.DataSource = DBHelper.Instance.GetRecords(query);
        }

        public void ShowDGV3(int id)
        {
            String query;
            if (id == 0)
            {
                query = "SELECT * FROM Participant ORDER BY ID_Appointment ASC";
            }
            else
            {
                query = "SELECT * FROM Participant WHERE ID_Appointment = " + id + " ORDER BY ID_Guest ASC";
            }
            dataGridView3.DataSource = DBHelper.Instance.GetRecords(query);
        }

        private void buttonAddApp_Click(object sender, EventArgs e)
        {
            String dt = monthCalendar1.SelectionRange.Start.ToShortDateString();
            Add_Appointment_Form f = new Add_Appointment_Form(dt);
            f.d = new Add_Appointment_Form.MyDel(ShowDGV1);
            f.d += new Add_Appointment_Form.MyDel(ShowDGV2);
            f.Show();
        }

        private void buttonShow_Click(object sender, EventArgs e)
        {
            String dt = monthCalendar1.SelectionRange.Start.ToShortDateString(); //MM/dd/yyyy
            ShowDGV1(dt);
            ShowDGV2(dt);
        }

        private void buttonShowAll_Click(object sender, EventArgs e)
        {
            ShowDGV1(null);
            ShowDGV2(null);
        }

        private void buttonShowPa_Click(object sender, EventArgs e)
        {
            if(dataGridView1.SelectedRows.Count > 0) 
            {
                List<int> li = new List<int>();
                foreach (DataGridViewRow i in dataGridView1.SelectedRows)
                {
                    li.Add(Convert.ToInt32(i.Cells["ID"].Value.ToString()));
                }
                foreach(int i in li)
                {
                    ShowDGV3(i);
                }
            }
            else 
            {
                ShowDGV3(0);
            }
        }
    }
}
